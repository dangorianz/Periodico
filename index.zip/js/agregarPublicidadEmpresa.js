const $btnAgregarEmpresa = document.getElementById('btnAgregarEmpresa')
const $btnAgregarPublicidad = document.getElementById('btnAgregarPublicidad')


$btnAgregarEmpresa.addEventListener('click',()=>{
    alert(document.getElementById('nombreEmpresaP').value)
    
    const url = 'https://diarionuevonorte.herokuapp.com/api/InsertarEmpresa'
        const data = {};
        data.nombreEmpresa = document.getElementById('nombreEmpresaP').value;

        let JSO = JSON.stringify(data)
        alert(JSO)
        fetch(url, {
            method: 'POST', // or 'PUT'
            body: JSO, // data can be `string` or {object}!
            headers:{
                'Content-Type': 'application/json'
            }
        }).then(res => res.json())
        .catch(error => console.error('Error:', error))
        .then(response => location.reload());
        // location.reload();
})
 /*
$btnAgregarPublicidad.addEventListener('click',()=>{

    const url = 'http://localhost:3000/api/InsertarPublicidad'
        const data = {};
        data.categoriaPublicidad;
        data.foto;
        data.estado = 'F';
        data.tipo;
        data.idEmpresa;

        let JSO = JSON.stringify(data)
        fetch(url, {
            method: 'POST', // or 'PUT'
            body: JSO, // data can be `string` or {object}!
            headers:{
                'Content-Type': 'application/json'
            }
        }).then(res => res.json())
        .catch(error => console.error('Error:', error))
        .then(response => alert('Nota Insertado'));
        location.reload();
})*/